(* Copyright (C) 1999-2006 Henry Cejtin, Matthew Fluet, Suresh
 *    Jagannathan, and Stephen Weeks.
 *
 * MLton is released under a HPND-style license.
 * See the file MLton-LICENSE for details.
 *)

functor RealComparisons (type t
                         val < : t * t -> bool
                         val <= : t * t -> bool) =
   struct
      fun > (a, b) = < (b, a)
      fun >= (a, b) = <= (b, a)
   end
