(* Copyright (C) 2017 Matthew Fluet.
 *
 * MLton is released under a HPND-style license.
 * See the file MLton-LICENSE for details.
 *)

structure SequenceMetaDataSize =
   struct
      val bytes : Int32.int = 12
   end
